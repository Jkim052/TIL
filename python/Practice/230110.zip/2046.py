a = int(input())
b = '#'*a
print(b)