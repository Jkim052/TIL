a = int(input())

print(a)