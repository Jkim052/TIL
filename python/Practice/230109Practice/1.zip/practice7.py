a = list((input().split()))

for n in a:
    print(n, end=' ')