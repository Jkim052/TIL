string = input().split()


for n in string:
    print(n, end=' ')