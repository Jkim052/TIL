sentence = input("문자열을 입력해주세요 > ")
number = int(input('숫자를 입력해주세요 > '))

print(sentence*number)