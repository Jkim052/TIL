sentence1 = input('첫 번째 문장을 입력해주세요 > ')
sentence2 = input('두 번째 문장을 입력해주세요 > ')

print(sentence1+sentence2)