number = int(input("숫자를 입력해주세요 > "))

print(number + 10)