number1 = int(input('첫 번째 숫자를 입력해주세요 > '))
number2 = int(input('두 번째 숫자를 입력해주세요 > '))
number3 = int(input('세 번째 숫자를 입력해주세요 > '))
number4 = int(input('네 번째 숫자를 입력해주세요 > '))
number5 = int(input('다섯 번째 숫자를 입력해주세요 > '))

number_list = [number1, number2, number3, number4, number5]

print(number_list)