name = input("이름을 입력해주세요 > ")
year = int(input("태어난 년도를 입력해주세요 > "))
age = str(2023 - year)

print("저의 이름은 "+name+"이고, 올해 나이는 "+age+"세 입니다.")