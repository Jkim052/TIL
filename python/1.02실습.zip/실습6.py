number1 = int(input('첫 번째 숫자를 입력해주세요 > '))
number2 = int(input('두 번째 숫자를 입력해주세요 > '))

print('더하기 연산 : '+ str(number1+number2))
print('빼기 연산 : ' +str(number1-number2))
print('곱하기 연산 : '+ str(number1*number2))
print('몫 연산 : ' +str(number1//number2))
print('나머지 연산 : '+ str(number1%number2))